# College_Portal
Academic project 2014

->Abstract

-Dr. S. & S. S. Ghandhy College of Engineering and Technology web portal is a web site which is developed in PHP and MySQL. Which is totally dynamic website having information about Dr. S. & S.S. Gandhi college. This website also provides facility to change web-content dynamically through admin panel. Web site will provide latest news, latest events, department wise staff detail, student section where students or visitors can download materials, etc. with interactive graphical user interface. Having such kind of web site over internet provides college information to new students and attracts new students for admissions and bringing college at new level in the competitive market.

->How to use

-Update database connection details in connection.php file & You can locate database(sql file) in database folder

->Link
http://mywork.0fees.us/
