<ul id="vertical-navigation">
					<li class=""> <a href="../index.php">Home</a> </li>
					<li class=""> <a href="#">About us</a> 
                        <ul>           
                            <li class=""> <a href="history.php">History</a> </li>                            
                            <li class=""> <a href="mandate.php">Mission & Mendate</a> </li>                           
                            <li class=""> <a href="infrastructure.php">Infrastructure</a> </li>                            
                            <li class=""> <a href="hostel.php">Hostel Facilities</a> </li>                            
                            <li class=""> <a href="coursedetail.php">Course Detail</a> </li>                          
                        </ul>                        
                    </li>                   
					<li class=""> <a href="#">Departments</a>
						<!-- Begin Child Items Group-->
						<ul>
							<!-- Begin Child Item-->
							<li class=""> <a href="#">Civil Engg.</a> 
							<ul>
                            	<li><a href="civil_dept.php">Facilities</a></li>
								<li><a href="Civil_Staff.php">Staff Detail</a></li>
							</ul>
							</li>
							<li class=""> <a href="#">Mechanical Engg.</a> 
							<ul>
                            	<li><a href="Mech_dept.php">Facilities</a></li>
								<li><a href="Mech_Staff.php">Staff Detail</a></li>
							</ul></li>
							<li class=""> <a href="#">Electrical Engg.</a> 
							<ul>
                            	<li><a href="Elec_dept.php">Facilities</a></li>
								<li><a href="Elec_Staff.php">Staff Detail</a></li>
							</ul></li>
							<li class=""> <a href="#">Automobile Engg.</a> 
							<ul>
                            	<li><a href="Auto_dept.php">Facilities</a></li>
								<li><a href="Auto_Staff.php">Staff Detail</a></li>
							</ul></li>
							<li class=""> <a href="#">Metallurgy Department</a>
								<ul>
                                <li><a href="metal_dept.php">Facilities</a></li>
								<li><a href="metal_Staff.php">Staff Detail</a></li>
							</ul></li>
							<li class=""> <a href="#">Power Electronics</a>
							<ul>
                            	<li><a href="Power_dept.php">Facilities</a></li>
								<li><a href="Power_Staff.php">Staff Detail</a></li>
							</ul></li>
							<li class=""> <a href="#">Textile Manufacturing</a> 
							<ul>
                            	<li><a href="textile_manu_dept.php">Facilities</a></li>
								<li><a href="textile_manu_Staff.php">Staff Detail</a></li>
							</ul></li>
							<li class=""> <a href="#">Textile Processing</a> 
							<ul>
                            	<li><a href="textile_Proces_dept.php">Facilities</a></li>
								<li><a href="textile_Proces_Staff.php">Staff Detail</a></li>
							</ul></li>
							<li class=""> <a href="#">Information Technology</a> 
							<ul>
                            	<li><a href="it_dept.php">Facilities</a></li>
								<li><a href="it_Staff.php">Staff Detail</a></li>
							</ul></li>
							<li class=""> <a href="#">General Department</a> 
							<ul>
								<li><a href="General_Staff.php">Staff Detail</a></li>
							</ul></li>
							<li class=""> <a href="Applied_sci_Staff.php">Applied Science Staff</a> </li>
							<li class=""> <a href="Office_Staff.php">Office Staff</a> </li>
						</ul>
					</li>
					<!-- End parent item -->					
					<li class=""> <a href="#">Results</a>
                    	<ul>
                            <li class=""> <a href="http://www.gtu.ac.in">GTU Result</a>                           
                            <li class=""> <a href="#">Mid Exam</a>
                            </li>
                        </ul>
                    </li>					
                    <li class=""> <a href="#">Downloads</a>
                        <ul>
                            <li class=""> <a href="http://www.gtu.ac.in/syllabus/DE_SchemeSyllabus.htm">GTU Syllabus</a>                           
                            </li>
                        </ul>
                    </li>
					<li class=""> <a href="#">Project</a> 
                    	<ul>
                            <li class=""> <a href="PWD.php">PWD</a> </li>
                        </ul>
                    </li>
					<li class=""> <a href="Placement.php">Placements</a> </li>					
					<li class=""> <a href="Tender.php">Tender</a> </li>					
				</ul>