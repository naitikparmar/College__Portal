<!Doctype html>
<html lang="en">
	<head>
    	<link rel="stylesheet" type="text/css" href="../css/style.css">
        <link rel="stylesheet" type="text/css" href="../css/style_1.css">
        <link rel="stylesheet" type="text/css" href="../css/cssTable.css">
        <link rel="stylesheet" style="text/css" href="../css/menu.css">
        <link rel="stylesheet" style="text/css" href="../css/footer.css">
        <script type='text/javascript' src='../Jquery/jquery-1.8.3.min.js'></script>
		<script type='text/javascript' src='../Jquery/menu.js'></script>
        <script src='../Jquery/jquery-1.8.3.min.js'></script>
		<script src='../Jquery/jquery.elevatezoom.js'></script>
        <style type="text/css">
        	p
			{
				font-family:"Lucida Sans Unicode";
				font-size:14px;
				color:#272727;
				text-align:justify;
			}
			h1
			{
				font-size:32px;
				color:#003A75;
			}
        </style>
   		<meta charset="utf-8">
    	<title>Welcome to Dr. S. &amp; S. S. Ghandhy College of Engineering &amp; Technology,Surat</title>
    </head>
    
    <body bgcolor="#5A5A5A">
    	<div class="container">
        	<div class="logo">
				<iframe src="../logo/logo.html" width="960" height="150" frameborder="0" scrolling="no" allowTransparency="true"></iframe>
            </div>
            <div class="nav">
<?php include 'navigatiomenu.php';
			?>			</div>
            <div class="info">
            	
                <div class="space">
                </div>
                <div class="content">
                    <br><br>
                    <strong><center><h1>Automobile Department</h1></center></strong>
                    <br><br>
                    <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The Department Of Automobile Department of this institute has been the most focused department, carrying out various activities like training and placement etc.</p>
                    <br>
                    <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Students learn diffrent types of subjects like hremodynamic and hydraulics, Automobile engines, Automobile electrical system, Fuels & lubricants, Vehicle body engineering,Basic automobile designs , Hydrolic and pneumatic devices, Earth moving machinary, Road transport Organization and much more.y</p>
                    <br>
                    <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;There are also Laboratories available with requied equipments.</p>
            	</div>
                <div class="space">
                </div>
            </div>
            <div id=footer style="border:0px">
				<?php
					include 'footer.php';
				?>
			</div>
			<div class="copyright">
				<center><b>Copyright © 2014 Dr. S. & S. S. Ghandhy College of Engineering & Technology,Surat</b\></center>
			</div>				
        </div>
    </body>
</html>
