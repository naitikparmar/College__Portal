<!Doctype html>
<html lang="en">
	<head>
    	<link rel="stylesheet" type="text/css" href="../css/style.css">
        <link rel="stylesheet" type="text/css" href="../css/style_1.css">
        <link rel="stylesheet" style="text/css" href="../css/menu.css">
        <link rel="stylesheet" style="text/css" href="../css/footer.css">
        <script type='text/javascript' src='../Jquery/jquery-1.8.3.min.js'></script>
		<script type='text/javascript' src='../Jquery/menu.js'></script>
        <script src='../Jquery/jquery-1.8.3.min.js'></script>
		<script src='../Jquery/jquery.elevatezoom.js'></script>
        <style>
			.li
			{
				font-size:14px;
				color:#333;
				text-justify:auto;
			}
		</style>
   		<meta charset="utf-8">
    	<title>Welcome to Dr. S. &amp; S. S. Ghandhy College of Engineering &amp; Technology,Surat</title>
    </head>
    
    <body bgcolor="#5A5A5A">
    	<div class="container">
        	<div class="logo">
				<iframe src="../logo/logo.html" width="960" height="150" frameborder="0" scrolling="no" allowTransparency="true"></iframe>
            </div>
            <div class="nav">
			<?php
			include  'navigatiomenu.php';
			?>
			</div>
            <div class="info">
            	<div class="right">
                </div>
                    <div class="content">
                    	<br>
                        <br>
                        <center><h1>Vision</h1></center>
                    	<br>
                        <ul>
                          	<li class="li">To be a unique centre of excellence in technical education and innovation by imparting qualitative training and developing competencies to meet the ever changing global needs.</li>
                        </ul>
						<br>
                        <br>
                        <center><h1>Mission</h1></center>
                        <br>
                        <p style="font-size:16px;font-weight:bold">The Institute Ensures Quality and Relevance Thtough:</p>
                        <br>
                        <ul>
                             <li class="li">To provide diploma and short term training programmes in engineering accordind to needs of industry, bussines and community.</li>                                            
                             <li class="li">To equip and upgrade our staff in professional competencies to deliver technical education including management and pedagogical keeping pace with technological development.</li>
                             <li class="li">To provide state of art infrastructure to stake holder.</li>
                             <li class="li">To provide employable skilled manpowerto stake holder for sustainable global economical growth.</li>
                             <li class="li">To establish productive collaboration between institute and industries through consultancy, training, faculty exchange and placement services and entrepreneurship culture.</li>
                        </ul>
                        <br>
                        
                    </div>
                <div class="left">
                </div>
            </div>
            <div id=footer style="border:0px">
				<?php
					include 'footer.php';
				?>
			</div>
			<div class="copyright">
				<center><b>Copyright © 2014 Dr. S. & S. S. Ghandhy College of Engineering & Technology,Surat</b\></center>
			</div>			
        </div>
    </body>
</html>
