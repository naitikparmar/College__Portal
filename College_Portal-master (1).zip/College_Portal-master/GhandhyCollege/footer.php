<div id="newsletter">
					<h2>Map</h2>					
					<img id="zoom_01" src='../images/gmaps.JPG' data-zoom-image="../images/gmaps.JPG" height="128px" width="300px"/>
					<script>
						$('#zoom_01').elevateZoom({
						zoomType: "inner",
						cursor: "crosshair",
						zoomWindowFadeIn: 500,
						zoomWindowFadeOut: 1050,
						scrollZoom:true
						});
					</script>
				</div>
				<div class="footbox">
					<h2>Useful Link</h2>
					<ul>
					<li><a href="Tender.php">Tender</a></li>
					<li><a href="http://www.gtu.ac.in/results.asp">Result</a></li>
					<li><a href="http://www.gtu.ac.in">GTU</a></li>
					<li class="last"><a href="RTI.php">RTI</a></li>
					</ul>
				</div>
				<div class="footbox">
					<h2>Download section</h2>
					<ul>
					<li><a href="Placement.php">Placement</a></li>
					<li><a href="../admin/login.html">Administration</a></li>
					<li><a href="PWD.php">PWD</a></li>
					<li class="last"><a href="hostel.php">Facilities</a></li>
					</ul>
				</div>
				<div class="footbox">
					<h2>Extra link</h2>
					<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="history.php">About us</a></li>
					<li><a href="feedback.php">Feedback</a></li>
					<li class="last"><a href="Contact_Us.php">Contact us</a></li>
					</ul>
				 </div>