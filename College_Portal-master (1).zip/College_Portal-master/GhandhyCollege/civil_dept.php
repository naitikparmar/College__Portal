<!Doctype html>
<html lang="en">
	<head>
    	<link rel="stylesheet" type="text/css" href="../css/style.css">
        <link rel="stylesheet" type="text/css" href="../css/style_1.css">
        <link rel="stylesheet" type="text/css" href="../css/cssTable.css">
        <link rel="stylesheet" style="text/css" href="../css/menu.css">
        <link rel="stylesheet" style="text/css" href="../css/footer.css">
        <script type='text/javascript' src='../Jquery/jquery-1.8.3.min.js'></script>
		<script type='text/javascript' src='../Jquery/menu.js'></script>
        <script src='../Jquery/jquery-1.8.3.min.js'></script>
		<script src='../Jquery/jquery.elevatezoom.js'></script>
        <style type="text/css">
        	p
			{
				font-family:"Lucida Sans Unicode";
				font-size:14px;
				color:#272727;
				text-align:justify;
			}
			h1
			{
				font-size:32px;
				color:#003A75;
			}
        </style>
   		<meta charset="utf-8">
    	<title>Welcome to Dr. S. &amp; S. S. Ghandhy College of Engineering &amp; Technology,Surat</title>
    </head>
    
    <body bgcolor="#5A5A5A">
    	<div class="container">
        	<div class="logo">
				<iframe src="../logo/logo.html" width="960" height="150" frameborder="0" scrolling="no" allowTransparency="true"></iframe>
            </div>
            <div class="nav">
<?php include 'navigatiomenu.php';
			?>			</div>
            <div class="info">
            	
                <div class="space">
                </div>
                <div class="content">
                    <br><br>
                    <strong><center><h1>Civil Department</h1></center></strong>
                    <br><br>
                    <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Civil engineering department comprises of two section: civil engineering department and applied mechanics. Both department are very well equipments and models. over and above the regular teaching works, many consultancy projects and material testing jobs are carried out in the department.</p>
                    <br>
                    <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Well qualified faculty members are carried out up-gradation of curriculum as per industry needs, attending training of earthquake and other civil engineering fields. Students are involved in projects, study tours, technical paper presentation , seminars, model creation and workshops.</p>
                    <br>
                    <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The Department of Civil Engineering of this Institute started in 1955 with the inception of this polytechnic with an intake capacity of 30 students which has been increased to 60. The Distance Learning Mode was introduced with the intake capacity of 30 seats.</p>
            	</div>
                <div class="space">
                </div>
            </div>
            <div id=footer style="border:0px">
				<?php
					include 'footer.php';
				?>
			</div>
			<div class="copyright">
				<center><b>Copyright © 2014 Dr. S. & S. S. Ghandhy College of Engineering & Technology,Surat</b\></center>
			</div>				
        </div>
    </body>
</html>
