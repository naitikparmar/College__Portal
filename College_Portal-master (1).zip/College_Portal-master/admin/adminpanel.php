<br>
<br>
<div style="border:0px solid #333">
<a href="adminsite.php" class="btnadminhome">Go to Admin Home</a>
<a href="logout.php" class="btnlogout" style="margin-left:500px;">Logout</a>
</div>
<br>
<br>
<br>
<br>