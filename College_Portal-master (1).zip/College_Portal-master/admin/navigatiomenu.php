<ul id="vertical-navigation">
                    <li class=""> <a href="../index.php">Home</a> </li>
                    <li class=""> <a href="#">About us</a> 
                        <ul>           
                            <li class=""> <a href="../GhandhyCollege/history.php">History</a> </li>                            
                            <li class=""> <a href="../GhandhyCollege/mandate.php">Mission & Mendate</a> </li>                           
                            <li class=""> <a href="../GhandhyCollege/infrastructure.php">Infrastructure</a> </li>                            
                            <li class=""> <a href="../GhandhyCollege/hostel.php">Hostel Facilities</a> </li>                            
                            <li class=""> <a href="../GhandhyCollege/coursedetail.php">Course Detail</a> </li>                          
                        </ul>                        
                    </li>                   
                    <li class=""> <a href="#">Departments</a>
                        <!-- Begin Child Items Group-->
                        <ul>
                            <!-- Begin Child Item-->
                            <li class=""> <a href="#">Civil Engg.</a> 
                            <ul>
								<li><a href="../GhandhyCollege/civil_dept.php">Facilities</a></li>
                                <li><a href="../GhandhyCollege/Civil_Staff.php">Staff Detail</a></li>
                            </ul>
                            </li>
                            <li class=""> <a href="#">Mechanical Engg.</a> 
                            <ul>
                            	<li><a href="../GhandhyCollege/Mech_dept.php">Facilities</a></li>
                                <li><a href="../GhandhyCollege/Mech_Staff.php">Staff Detail</a></li>
                            </ul></li>
                            <li class=""> <a href="#">Electrical Engg.</a> 
                            <ul>
                            	<li><a href="../GhandhyCollege/Elec_dept.php">Facilities</a></li>
                                <li><a href="../GhandhyCollege/Elec_Staff.php">Staff Detail</a></li>
                            </ul></li>
                            <li class=""> <a href="#">Automobile Engg.</a> 
                            <ul>
                            	<li><a href="../GhandhyCollege/Auto_dept.php">Facilities</a></li>
                                <li><a href="../GhandhyCollege/Auto_Staff.php">Staff Detail</a></li>
                            </ul></li>
                            <li class=""> <a href="#">Metallurgy Department</a>
                                <ul>
                                <li><a href="../GhandhyCollege/metal_dept.php">Facilities</a></li>
                                <li><a href="../GhandhyCollege/metal_Staff.php">Staff Detail</a></li>
                            </ul></li>
                            <li class=""> <a href="#">Power Electronics</a>
                            <ul>
                            	<li><a href="../GhandhyCollege/Power_dept.php">Facilities</a></li>
                                <li><a href="../GhandhyCollege/Power_Staff.php">Staff Detail</a></li>
                            </ul></li>
                            <li class=""> <a href="#">Textile Manufacturing</a> 
                            <ul>
                            	<li><a href="../GhandhyCollege/textile_manu_dept.php">Facilities</a></li>
                                <li><a href="../GhandhyCollege/textile_manu_Staff.php">Staff Detail</a></li>
                            </ul></li>
                            <li class=""> <a href="#">Textile Processing</a> 
                            <ul>
                            	<li><a href="../GhandhyCollege/textile_proces_dept.php">Facilities</a></li>
                                <li><a href="../GhandhyCollege/textile_Proces_Staff.php">Staff Detail</a></li>
                            </ul></li>
                            <li class=""> <a href="#">Information Technology</a> 
                            <ul>
                            	<li><a href="../GhandhyCollege/it_dept.php">Facilities</a></li>
                                <li><a href="../GhandhyCollege/it_Staff.php">Staff Detail</a></li>
                            </ul></li>
                            <li class=""> <a href="#">General Department</a> 
                            <ul>
                                <li><a href="../GhandhyCollege/General_Staff.php">Staff Detail</a></li>
                            </ul></li>
                            <li class=""> <a href="../GhandhyCollege/Applied_sci_Staff.php">Applied Science Staff</a>
                            </li>
                            <li class=""> <a href="../GhandhyCollege/Office_Staff.php">Office Staff</a>
                            </li>
                        </ul>
                    </li>
                    <!-- End parent item -->					
                    <li class=""> <a href="#">Results</a>
                    	<ul>
                            <li class=""> <a href="http://www.gtu.ac.in">GTU Result</a>                           
                            <li class=""> <a href="#">Mid Exam</a>
                            </li>
                        </ul>
                    </li>					
                    <li class=""> <a href="#">Downloads</a>
                        <ul>
                            <li class=""> <a href="http://www.gtu.ac.in/syllabus/DE_SchemeSyllabus.htm">GTU Syllabus</a>                           
                            </li>
                        </ul>
                    </li>
                    <li class=""> <a href="#">Project</a> 
                        <ul>
                            <li class=""> <a href="../GhandhyCollege/PWD.php">PWD</a> </li>
                        </ul>
                    </li>
                    <li class=""> <a href="../GhandhyCollege/Placement.php">Placements</a> </li>					
                    <li class=""> <a href="../GhandhyCollege/Tender.php">Tender</a> </li>					
                </ul>